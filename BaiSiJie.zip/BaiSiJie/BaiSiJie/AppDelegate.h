//
//  AppDelegate.h
//  BaiSiJie
//
//  Created by 郑雪利 on 2017/7/6.
//  Copyright © 2017年 郑雪利. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

