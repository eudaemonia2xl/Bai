//
//  BSUserCell.h
//  BaiSiJie
//
//  Created by senyint on 2017/7/18.
//  Copyright © 2017年 郑雪利. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BSRecommandUser;
@interface BSUserCell : UITableViewCell

@property (nonatomic, strong) BSRecommandUser *user;

@end
