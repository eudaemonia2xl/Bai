//
//  BSCategoryCell.h
//  BaiSiJie
//
//  Created by senyint on 2017/7/18.
//  Copyright © 2017年 郑雪利. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BSRecommandCategory;
@interface BSCategoryCell : UITableViewCell

//cell上模型
@property (nonatomic, strong) BSRecommandCategory *category;

@end
